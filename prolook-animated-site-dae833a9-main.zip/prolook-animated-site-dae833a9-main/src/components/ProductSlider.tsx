import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

const ProductSlider = () => {
  const products = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1582562124811-c09040d0a901",
      title: "Premium Textiles",
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1466721591366-2d5fba72006d",
      title: "Custom Uniforms",
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1",
      title: "Embroidery Services",
    },
    {
      id: 4,
      image: "/lovable-uploads/6abf9000-5f4b-47d6-aabe-c3c0fd488c7d.png",
      title: "Professional Attire",
    },
    {
      id: 5,
      image: "https://images.unsplash.com/photo-1582562124811-c09040d0a901",
      title: "Event Wear",
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="w-full max-w-6xl mx-auto px-4 py-12"
    >
      <h2 className="text-3xl font-bold text-prolook-navy mb-8 text-center">
        Our Products
      </h2>
      <Carousel
        opts={{
          align: "start",
          loop: true,
        }}
        className="w-full"
      >
        <CarouselContent>
          {products.map((product) => (
            <CarouselItem key={product.id} className="md:basis-1/2 lg:basis-1/3">
              <Card className="border-none shadow-lg">
                <CardContent className="p-2">
                  <div className="overflow-hidden rounded-lg aspect-square">
                    <img
                      src={product.image}
                      alt={product.title}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                  </div>
                  <h3 className="text-xl font-semibold text-prolook-navy mt-4 text-center">
                    {product.title}
                  </h3>
                </CardContent>
              </Card>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious className="hidden md:flex" />
        <CarouselNext className="hidden md:flex" />
      </Carousel>
    </motion.div>
  );
};

export default ProductSlider;