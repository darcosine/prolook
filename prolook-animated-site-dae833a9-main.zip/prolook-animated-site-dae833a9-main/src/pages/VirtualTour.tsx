import { useEffect } from "react";
import Navigation from "../components/Navigation";
import { motion } from "framer-motion";

const VirtualTour = () => {
  useEffect(() => {
    document.title = "Virtual Tour - Prolook Clothing & Textiles";
  }, []);

  const staff = [
    {
      name: "Production Team",
      description: "Our skilled production team ensures quality in every stitch",
      image: "https://images.unsplash.com/photo-1564859228273-274232fdb516"
    },
    {
      name: "Design Studio",
      description: "Where creativity meets craftsmanship",
      image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8"
    },
    {
      name: "Embroidery Section",
      description: "State-of-the-art embroidery machines and skilled operators",
      image: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633"
    }
  ];

  const owner = {
    name: "John Smith",
    title: "Founder & CEO",
    description: "With over 20 years of experience in the textile industry, John has built Prolook into a leading provider of premium clothing and textile solutions.",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-prolook-navy to-prolook-blue/90">
      <Navigation />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="container mx-auto px-4 pt-24 pb-12"
      >
        <div className="bg-white/95 backdrop-blur-md rounded-3xl shadow-2xl p-8 mb-8">
          <div className="flex items-center gap-4 mb-8">
            <img
              src="/lovable-uploads/6abf9000-5f4b-47d6-aabe-c3c0fd488c7d.png"
              alt="Prolook Logo"
              className="h-16 w-auto"
            />
            <h1 className="text-4xl font-bold text-prolook-navy">Virtual Tour</h1>
          </div>

          {/* Owner Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="bg-white rounded-2xl shadow-lg overflow-hidden mb-12 max-w-4xl mx-auto"
          >
            <div className="md:flex">
              <div className="md:w-1/3">
                <img
                  src={owner.image}
                  alt={owner.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="md:w-2/3 p-8">
                <h2 className="text-2xl font-bold text-prolook-navy mb-2">{owner.name}</h2>
                <h3 className="text-lg text-prolook-blue mb-4">{owner.title}</h3>
                <p className="text-gray-600">{owner.description}</p>
              </div>
            </div>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {staff.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              >
                <div className="aspect-video relative">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-prolook-navy mb-2">{member.name}</h3>
                  <p className="text-gray-600">{member.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default VirtualTour;